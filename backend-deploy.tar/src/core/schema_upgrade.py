from __future__ import annotations

from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from core.config import settings
from core.dependencies import hash_password, utcnow_naive
from core.identity import build_default_display_name, generate_stable_user_uuid, generate_user_uuid
from core.logging_config import logger
from core.plan_catalog import build_limit_rule, get_default_test_plan, get_free_plan
from db.base import Base, engine
from db.models import (
    AccountToken,
    DeviceAuthorization,
    PaymentOrder,
    RefreshToken,
    RequestLog,
    User,
    UserIdentityLink,
    UserSession,
)


def _add_column_if_missing(db: Session, columns: list[str], column_name: str, ddl: str) -> None:
    if column_name in columns:
        return
    db.execute(text(ddl))
    columns.append(column_name)
    logger.info("Added column %s", column_name)


def _ensure_table_columns(db: Session) -> None:
    inspector = inspect(engine)

    if "user" in inspector.get_table_names():
        user_columns = [col["name"] for col in inspector.get_columns("user")]
        _add_column_if_missing(db, user_columns, "user_uuid", "ALTER TABLE user ADD COLUMN user_uuid VARCHAR(36)")
        _add_column_if_missing(db, user_columns, "email", "ALTER TABLE user ADD COLUMN email VARCHAR(255)")
        _add_column_if_missing(db, user_columns, "email_verified", "ALTER TABLE user ADD COLUMN email_verified BOOLEAN DEFAULT 0")
        _add_column_if_missing(db, user_columns, "display_name", "ALTER TABLE user ADD COLUMN display_name VARCHAR(100)")
        _add_column_if_missing(db, user_columns, "is_default_test_user", "ALTER TABLE user ADD COLUMN is_default_test_user BOOLEAN DEFAULT 0")
        _add_column_if_missing(db, user_columns, "identity_version", "ALTER TABLE user ADD COLUMN identity_version INTEGER DEFAULT 1")
        _add_column_if_missing(db, user_columns, "expiration_date", "ALTER TABLE user ADD COLUMN expiration_date DATETIME")
        _add_column_if_missing(db, user_columns, "is_active", "ALTER TABLE user ADD COLUMN is_active BOOLEAN DEFAULT 1")
        _add_column_if_missing(db, user_columns, "created_at", "ALTER TABLE user ADD COLUMN created_at DATETIME")
        _add_column_if_missing(db, user_columns, "last_login_at", "ALTER TABLE user ADD COLUMN last_login_at DATETIME")
        _add_column_if_missing(db, user_columns, "boost_expiration_date", "ALTER TABLE user ADD COLUMN boost_expiration_date DATETIME")
        _add_column_if_missing(db, user_columns, "boost_limit_rule", "ALTER TABLE user ADD COLUMN boost_limit_rule VARCHAR(100)")
        _add_column_if_missing(db, user_columns, "addon_resource_balance", "ALTER TABLE user ADD COLUMN addon_resource_balance INTEGER DEFAULT 0")
        _add_column_if_missing(db, user_columns, "addon_resource_total", "ALTER TABLE user ADD COLUMN addon_resource_total INTEGER DEFAULT 0")
        _add_column_if_missing(db, user_columns, "addon_expiration_date", "ALTER TABLE user ADD COLUMN addon_expiration_date DATETIME")

    for table_name, column_name, ddl in [
        ("account_token", "code", "ALTER TABLE account_token ADD COLUMN code VARCHAR(16)"),
        ("account_token", "user_uuid", "ALTER TABLE account_token ADD COLUMN user_uuid VARCHAR(36)"),
        ("user_session", "user_uuid", "ALTER TABLE user_session ADD COLUMN user_uuid VARCHAR(36)"),
        ("refresh_token", "user_uuid", "ALTER TABLE refresh_token ADD COLUMN user_uuid VARCHAR(36)"),
        ("device_authorization", "user_uuid", "ALTER TABLE device_authorization ADD COLUMN user_uuid VARCHAR(36)"),
        ("request_log", "status", "ALTER TABLE request_log ADD COLUMN status VARCHAR(20) DEFAULT 'pending'"),
        ("request_log", "resource_cost", "ALTER TABLE request_log ADD COLUMN resource_cost INTEGER DEFAULT 0"),
        ("request_log", "resource_deducted", "ALTER TABLE request_log ADD COLUMN resource_deducted BOOLEAN DEFAULT 0"),
        ("request_log", "quota_source", "ALTER TABLE request_log ADD COLUMN quota_source VARCHAR(20) DEFAULT 'none'"),
        ("request_log", "user_uuid", "ALTER TABLE request_log ADD COLUMN user_uuid VARCHAR(36)"),
        ("request_log", "actor_type", "ALTER TABLE request_log ADD COLUMN actor_type VARCHAR(32)"),
        ("request_log", "rate_limit_scope", "ALTER TABLE request_log ADD COLUMN rate_limit_scope VARCHAR(32)"),
        ("request_log", "quota_scope", "ALTER TABLE request_log ADD COLUMN quota_scope VARCHAR(32)"),
        ("payment_order", "custom_id_digest", "ALTER TABLE payment_order ADD COLUMN custom_id_digest VARCHAR(64)"),
        ("payment_order", "remark_digest", "ALTER TABLE payment_order ADD COLUMN remark_digest VARCHAR(64)"),
        ("payment_order", "activation_source", "ALTER TABLE payment_order ADD COLUMN activation_source VARCHAR(64)"),
        ("payment_order", "activation_error", "ALTER TABLE payment_order ADD COLUMN activation_error TEXT"),
        ("payment_order", "activation_error_at", "ALTER TABLE payment_order ADD COLUMN activation_error_at DATETIME"),
        ("payment_order", "user_uuid", "ALTER TABLE payment_order ADD COLUMN user_uuid VARCHAR(36)"),
        ("payment_order", "email", "ALTER TABLE payment_order ADD COLUMN email VARCHAR(255)"),
        ("payment_order", "plan_id", "ALTER TABLE payment_order ADD COLUMN plan_id VARCHAR(64)"),
        ("payment_order", "billing_version", "ALTER TABLE payment_order ADD COLUMN billing_version INTEGER DEFAULT 1"),
    ]:
        if table_name not in inspector.get_table_names():
            continue
        columns = [col["name"] for col in inspector.get_columns(table_name)]
        _add_column_if_missing(db, columns, column_name, ddl)


def _backfill_users(db: Session) -> None:
    free_plan = get_free_plan()
    for user in db.query(User).all():
        if not (user.user_uuid or "").strip():
            user.user_uuid = generate_stable_user_uuid(user.id, user.username)
        if not (getattr(user, "display_name", None) or "").strip():
            user.display_name = build_default_display_name(user_uuid=user.user_uuid, user_id=user.id)
        if getattr(user, "identity_version", None) in (None, 0):
            user.identity_version = 2 if user.email and user.email_verified else 1
        if user.limit_rule is None:
            user.limit_rule = build_limit_rule(settings.FREE_PLAN_LIMIT_RULE, free_plan["id"], free_plan["daily_quota"])
        if user.is_active is None:
            user.is_active = True
        if user.created_at is None:
            user.created_at = utcnow_naive()


def _backfill_related_tables(db: Session) -> None:
    users_by_username = {user.username: user for user in db.query(User).all()}
    users_by_id = {user.id: user for user in db.query(User).all()}

    for record in db.query(AccountToken).all():
        if not record.user_uuid and record.username in users_by_username:
            user = users_by_username[record.username]
            record.user_uuid = user.user_uuid
            if not record.email and user.email:
                record.email = user.email

    for record in db.query(UserSession).all():
        if not record.user_uuid and record.user_id in users_by_id:
            record.user_uuid = users_by_id[record.user_id].user_uuid

    for record in db.query(RefreshToken).all():
        if not record.user_uuid and record.user_id in users_by_id:
            record.user_uuid = users_by_id[record.user_id].user_uuid

    for record in db.query(DeviceAuthorization).all():
        if not record.user_uuid and record.user_id in users_by_id:
            record.user_uuid = users_by_id[record.user_id].user_uuid

    for record in db.query(RequestLog).all():
        if not record.user_uuid and record.username in users_by_username:
            user = users_by_username[record.username]
            record.user_uuid = user.user_uuid
        if not record.actor_type:
            record.actor_type = "authenticated"
        if not record.rate_limit_scope:
            record.rate_limit_scope = "user"
        if not record.quota_scope:
            record.quota_scope = "user"

    for record in db.query(PaymentOrder).all():
        user = users_by_username.get(record.username or "")
        if user is not None and not record.user_uuid:
            record.user_uuid = user.user_uuid
        if user is not None and not record.email and user.email:
            record.email = user.email
        if not record.billing_version:
            record.billing_version = 1


def _ensure_default_test_user(db: Session) -> None:
    if not settings.DEFAULT_TEST_USER_ENABLED:
        return

    plan = get_default_test_plan()
    user = db.query(User).filter(User.user_uuid == settings.DEFAULT_TEST_USER_UUID).first()
    if user is None and settings.DEFAULT_TEST_USER_USERNAME:
        user = db.query(User).filter(User.username == settings.DEFAULT_TEST_USER_USERNAME).first()

    if user is None:
        password = settings.DEFAULT_TEST_USER_PASSWORD or generate_user_uuid()
        user = User(
            user_uuid=settings.DEFAULT_TEST_USER_UUID,
            username=settings.DEFAULT_TEST_USER_USERNAME,
            password=hash_password(password),
            email=settings.DEFAULT_TEST_USER_EMAIL,
            email_verified=False,
            display_name=settings.DEFAULT_TEST_USER_DISPLAY_NAME,
            is_default_test_user=True,
            identity_version=1,
            is_active=bool(settings.DEFAULT_TEST_USER_ACTIVE),
            limit_rule=build_limit_rule(settings.FREE_PLAN_LIMIT_RULE, plan["id"], plan["daily_quota"]),
            created_at=utcnow_naive(),
        )
        db.add(user)
        db.flush()
        logger.info("Created default test user %s", user.user_uuid)
    else:
        user.user_uuid = settings.DEFAULT_TEST_USER_UUID
        user.username = settings.DEFAULT_TEST_USER_USERNAME or user.username
        user.email = user.email or settings.DEFAULT_TEST_USER_EMAIL
        user.display_name = user.display_name or settings.DEFAULT_TEST_USER_DISPLAY_NAME
        user.is_default_test_user = True
        user.identity_version = 1
        user.is_active = bool(settings.DEFAULT_TEST_USER_ACTIVE)
        user.limit_rule = build_limit_rule(settings.FREE_PLAN_LIMIT_RULE, plan["id"], plan["daily_quota"])


def run_schema_upgrade() -> None:
    Base.metadata.create_all(bind=engine)
    db = Session(bind=engine)
    try:
        _ensure_table_columns(db)
        db.flush()
        _backfill_users(db)
        _backfill_related_tables(db)
        _ensure_default_test_user(db)
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
