import asyncio
import httpx
import json
import os
import html
import traceback
import struct
import wave
import re

from io import BytesIO
from openai import OpenAI, AsyncOpenAI
import opuslib
import emoji
from core.config import settings, WHISPER_URL, WHISPER_TRT_URL, SENSEVOICE_URL
from core.gemma_translate_service import gemma_translate, is_gemma_translation_supported
from core.logging_config import logger
from core.text_compressor import compress_repeated_chars
from core.update_service import get_translation_capabilities

# 延迟导入translators，避免初始化时的网络问题
translators = None

def get_translators():
    global translators
    if translators is None:
        # 从环境变量获取地区设置，避免网络检查
        region = os.environ.get("translators_default_region", "CN")
        os.environ["translators_default_region"] = region
        import translators as _translators
        translators = _translators
    return translators


# --- 全局客户端和服务变量 ---
# 同步客户端（保留用于向后兼容）
whisperclient = OpenAI(api_key=settings.WHISPER_APIKEY, base_url=WHISPER_URL)
# 异步客户端（推荐使用，避免阻塞事件循环）
async_whisperclient = AsyncOpenAI(api_key=settings.WHISPER_APIKEY, base_url=WHISPER_URL)

glm_client = OpenAI(api_key="4c3d963619884fc69e3a02c581925691.mgFDmvFyfDWmGvub", base_url="https://open.bigmodel.cn/api/paas/v4/")
errorFilter = {}
# 硬编码的支持语言列表，不再动态从LibreTranslate获取
supportedLanguagesList = [
    "ar", "az", "bg", "bn", "ca", "cs", "da", "de", "el", "en",
    "eo", "es", "et", "eu", "fa", "fi", "fr", "ga", "gl", "he",
    "hi", "hu", "id", "it", "ja", "ko", "lt", "lv", "ms", "nb",
    "nl", "pl", "pt", "ro", "ru", "sk", "sl", "sq", "sv", "th",
    "tl", "tr", "uk", "ur", "zh", "zt"
]

# --- 语言代码 (从 server.py 复制) ---
whisperSupportedLanguageList = ["af","am","ar","as","az","ba","be","bg","bn","bo","br","bs","ca","cs","cy","da","de","el","en","es","et","eu","fa","fi","fo","fr","gl","gu","ha","haw","he","hi","hr","ht","hu","hy","id","is","it","ja","jw","ka","kk","km","kn","ko","la","lb","ln","lo","lt","lv","mg","mi","mk","ml","mn","mr","ms","mt","my","ne","nl","nn","no","oc","pa","pl","ps","pt","ro","ru","sa","sd","si","sk","sl","sn","so","sq","sr","su","sv","sw","ta","te","tg","th","tk","tl","tr","tt","uk","ur","uz","vi","yi","yo","yue","zh"]
codeTochinese = {'af':'阿非利堪斯语','am':'阿姆哈拉语','ar':'阿拉伯语','as':'阿萨姆语','az':'阿塞拜疆语','ba':'巴什基尔语','be':'白俄罗斯语','bg':'保加利亚语','bn':'孟加拉语','bo':'藏语','br':'布列塔尼语','bs':'波斯尼亚语','ca':'加泰罗尼亚语','cs':'捷克语','cy':'威尔士语','da':'丹麦语','de':'德语','el':'希腊语','en':'英语','es':'西班牙语','et':'爱沙尼亚语','eu':'巴斯克语','fa':'波斯语','fi':'芬兰语','fo':'法罗语','fr':'法语','gl':'加利西亚语','gu':'古吉拉特语','ha':'豪萨语','haw':'夏威夷语','he':'希伯来语','hi':'印地语','hr':'克罗地亚语','ht':'海地克里奥尔语','hu':'匈牙利语','hy':'亚美尼亚语','id':'印尼语','is':'冰岛语','it':'意大利语','ja':'日语','jw':'爪哇语','ka':'格鲁吉亚语','kk':'哈萨克语','km':'高棉语','kn':'卡纳达语','ko':'韩语','la':'拉丁语','lb':'卢森堡语','ln':'林加拉语','lo':'老挝语','lt':'立陶宛语','lv':'拉脱维亚语','mg':'马达加斯加语','mi':'毛利语','mk':'马其顿语','ml':'马拉雅拉姆语','mn':'蒙古语','mr':'马拉地语','ms':'马来语','mt':'马耳他语','my':'缅甸语','ne':'尼泊尔语','nl':'荷兰语','nn':'新挪威语','no':'挪威语','oc':'奥克语','pa':'旁遮普语','pl':'波兰语','ps':'普什图语','pt':'葡萄牙语','ro':'罗马尼亚语','ru':'俄语','sa':'梵语','sd':'信德语','si':'僧伽罗语','sk':'斯洛伐克语','sl':'斯洛文尼亚语','sn':'修纳语','so':'索马里语','sq':'阿尔巴尼亚语','sr':'塞尔维亚语','su':'巽他语','sv':'瑞典语','sw':'斯瓦希里语','ta':'泰米尔语','te':'泰卢固语','tg':'塔吉克语','th':'泰语','tk':'土库曼语','tl':'他加禄语','tr':'土耳其语','tt':'鞑靼语','uk':'乌克兰语','ur':'乌尔都语','uz':'乌兹别克语','vi':'越南语','yi':'意第绪语','yo':'约鲁巴语','yue':'粤语','zh':'简体中文','zt':'繁体中文','eo':'世界语','ga':'爱尔兰语','nb':'挪威语'}
transalte_zt = {'bing':'zh-Hant','baidu':'cht','alibaba':'zh-TW','sogou':'zh-CHT','iciba':'cnt','itranslate':'zh-TW','papago':'zh-TW'}

LANG_CANONICAL_MAPPING = {
    "zh": "zh",
    "zh-cn": "zh",
    "zh-sg": "zh",
    "zh-hans": "zh",
    "zt": "zt",
    "zh-hant": "zt",
    "zh-tw": "zt",
    "zh-hk": "zt",
    "zh-mo": "zt",
}


def _canonical_lang_code(lang: str) -> str:
    raw = (lang or "").strip().lower()
    if not raw:
        return raw
    if raw in LANG_CANONICAL_MAPPING:
        return LANG_CANONICAL_MAPPING[raw]
    if "-" in raw:
        base = raw.split("-", 1)[0]
        return LANG_CANONICAL_MAPPING.get(base, base)
    return raw


def _is_same_translation_lang(source_lang: str, target_lang: str) -> bool:
    source = _canonical_lang_code(source_lang)
    target = _canonical_lang_code(target_lang)
    if not source or not target:
        return False
    return source == target


def _is_auto_translation_lang(lang: str) -> bool:
    return (lang or "").strip().lower() == "auto"


def normalize_translation_language_code(lang: str) -> str:
    return _canonical_lang_code(lang)


def _iter_capability_targets(raw_targets):
    if isinstance(raw_targets, dict):
        return raw_targets.keys()
    if isinstance(raw_targets, (list, tuple, set)):
        return raw_targets
    if isinstance(raw_targets, str):
        return [raw_targets]
    return []


def get_runtime_translation_language_sets():
    source_languages = set()
    target_languages = set()

    try:
        capabilities = get_translation_capabilities()
        engines = capabilities.get("engines", []) if isinstance(capabilities, dict) else []

        for engine in engines:
            language_map = engine.get("languages", {}) if isinstance(engine, dict) else {}
            if not isinstance(language_map, dict):
                continue

            for raw_source, raw_targets in language_map.items():
                source = _canonical_lang_code(str(raw_source))
                if source and not _is_auto_translation_lang(source):
                    source_languages.add(source)

                for raw_target in _iter_capability_targets(raw_targets):
                    target = _canonical_lang_code(str(raw_target))
                    if target and not _is_auto_translation_lang(target):
                        target_languages.add(target)
    except Exception as exc:  # pylint: disable=broad-except
        logger.warning("[TRANSLATE] Failed to load runtime translation capabilities: %s", exc)

    if not source_languages:
        source_languages.update(supportedLanguagesList)
    if not target_languages:
        target_languages.update(supportedLanguagesList)

    return {
        "sources": sorted(source_languages),
        "targets": sorted(target_languages),
    }


def get_runtime_translation_source_languages():
    return get_runtime_translation_language_sets()["sources"]


def get_runtime_translation_target_languages():
    return get_runtime_translation_language_sets()["targets"]


def is_runtime_translation_source_supported(lang: str) -> bool:
    normalized = _canonical_lang_code(lang)
    return normalized in set(get_runtime_translation_source_languages())


def is_runtime_translation_target_supported(lang: str) -> bool:
    normalized = _canonical_lang_code(lang)
    return normalized in set(get_runtime_translation_target_languages())


SCRIPT_LANGUAGE_RANGES = {
    "ko": [(0xAC00, 0xD7AF), (0x1100, 0x11FF), (0x3130, 0x318F)],
    "ja": [(0x3040, 0x309F), (0x30A0, 0x30FF), (0x31F0, 0x31FF)],
    "ru": [(0x0400, 0x04FF), (0x0500, 0x052F)],
    "ar": [(0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF)],
    "hi": [(0x0900, 0x097F)],
    "th": [(0x0E00, 0x0E7F)],
    "he": [(0x0590, 0x05FF)],
    "el": [(0x0370, 0x03FF)],
}

LATIN_LANGUAGE_HINTS = {
    "en": {"the", "and", "you", "this", "that", "are", "with", "have", "what", "please", "hello"},
    "de": {"der", "die", "das", "und", "ist", "nicht", "ich", "mit", "ein", "eine", "bitte", "hallo"},
    "fr": {"le", "la", "les", "de", "des", "est", "pas", "que", "pour", "une", "bonjour", "merci"},
    "es": {"el", "la", "los", "las", "de", "que", "para", "por", "una", "gracias", "hola", "estoy"},
    "pt": {"de", "que", "para", "por", "uma", "obrigado", "ola", "voce", "estou", "nao"},
    "it": {"che", "per", "una", "grazie", "ciao", "sono", "non", "con", "del", "della"},
    "nl": {"de", "het", "een", "en", "voor", "niet", "hallo", "dank", "ik", "jij"},
}

TRADITIONAL_CHINESE_HINTS = set("體對會說這個們來時後開關讓歡國語麼嗎學習點電腦網頁輸入龍貓貝萬與")


def _count_chars_in_ranges(text: str, ranges: list[tuple[int, int]]) -> int:
    count = 0
    for ch in text:
        code = ord(ch)
        for start, end in ranges:
            if start <= code <= end:
                count += 1
                break
    return count


def _contains_cjk(text: str) -> bool:
    return any(
        0x4E00 <= ord(ch) <= 0x9FFF
        or 0x3400 <= ord(ch) <= 0x4DBF
        for ch in text
    )


def _detect_script_language(text: str) -> str | None:
    scores = {
        lang: _count_chars_in_ranges(text, ranges)
        for lang, ranges in SCRIPT_LANGUAGE_RANGES.items()
    }

    best_lang = None
    best_score = 0
    for lang, score in scores.items():
        if score > best_score:
            best_lang = lang
            best_score = score

    if best_lang and best_score > 0:
        return best_lang

    if _contains_cjk(text):
        traditional_hits = sum(1 for ch in text if ch in TRADITIONAL_CHINESE_HINTS)
        return "zt" if traditional_hits > 0 else "zh"

    return None


def _detect_latin_language(text: str) -> str | None:
    tokens = re.findall(r"[a-zA-ZÀ-ÿ']+", text.lower())
    if not tokens:
        return None

    scores: dict[str, int] = {}
    for lang, hints in LATIN_LANGUAGE_HINTS.items():
        score = sum(1 for token in tokens if token in hints)
        if score > 0:
            scores[lang] = score

    if not scores:
        return "en"

    return max(scores.items(), key=lambda item: item[1])[0]


def detect_translation_source_language(text: str, allowed_languages: list[str] | None = None) -> str:
    allowed = {
        _canonical_lang_code(lang)
        for lang in (allowed_languages or get_runtime_translation_source_languages())
        if lang and not _is_auto_translation_lang(lang)
    }

    detected = _detect_script_language(text) or _detect_latin_language(text) or "en"
    canonical = _canonical_lang_code(detected)

    if canonical in allowed:
        return canonical

    if canonical == "zt" and "zh" in allowed:
        return "zh"

    if "en" in allowed:
        return "en"

    if "zh" in allowed:
        return "zh"

    return next(iter(allowed), "en")


# --- 初始化函数 ---
def load_filter_config():
    global errorFilter
    filter_path = os.path.join(os.path.dirname(__file__), '..', 'filter.json')

    try:
        # 首先加载本地配置
        with open(filter_path, 'r', encoding='utf-8') as f:
            local_config = json.load(f)
            logger.info("Loaded local filter config.")

        # 如果配置了网络URL，尝试获取网络配置并合并
        if settings.FILTER_WEB_URL:
            try:
                with httpx.Client(timeout=10.0) as client:
                    response = client.get(settings.FILTER_WEB_URL)
                    response.raise_for_status()
                    web_config = response.json()

                    # 合并配置：网络配置优先，补充本地配置
                    merged_config = {
                        "errorResultDict": list(set(web_config.get("errorResultDict", []) + local_config.get("errorResultDict", []))),
                        "errorKeyString": list(set(web_config.get("errorKeyString", []) + local_config.get("errorKeyString", [])))
                    }
                    
                    # 不要重新赋值，而是清空并更新原始字典
                    errorFilter.clear()
                    errorFilter.update(merged_config)
                    
                    logger.info("Successfully merged filter config from web and local.")
                    return
            except Exception as e:
                logger.warning(f"Failed to load filter from web, using local config. Error: {e}")
        # 使用本地配置
        errorFilter.clear()
        errorFilter.update(local_config)
        logger.info("Using local filter config.")

    except Exception as e:
        logger.error(f"Failed to load filter config: {e}")
        # 设置默认空配置
        errorFilter = {"errorResultDict": [], "errorKeyString": []}
        logger.warning("Using empty filter config due to load failure.")

def update_filter_config():
    """定时更新filter配置的函数"""
    logger.info("开始检查filter配置更新...")
    try:
        load_filter_config()
        logger.info(f"Filter配置更新完成，当前规则数: errorResultDict={len(errorFilter.get('errorResultDict', []))}, errorKeyString={len(errorFilter.get('errorKeyString', []))}")
    except Exception as e:
        logger.error(f"Filter配置更新失败: {e}")

def init_supported_languages():
    """
    初始化支持语言列表 - 现在使用硬编码的固定列表，不再动态获取
    原有server.py中是从LibreTranslate动态获取，现在改为固定列表以提高稳定性
    """
    global supportedLanguagesList
    # supportedLanguagesList 现在已经在模块级别硬编码初始化
    # 这个函数保留用于向后兼容，只记录日志
    logger.info(f"[INIT] 使用硬编码的支持语言列表，包含 {len(supportedLanguagesList)} 种语言: {supportedLanguagesList}")

# --- 业务逻辑函数 ---

# --- 异步Whisper函数 ---

async def async_transcribe(audio_file: bytes, language: str = 'zh') -> str:
    """
    异步语音转文字（ASR）
    使用AsyncOpenAI客户端，避免阻塞事件循环

    Args:
        audio_file: 音频文件字节数据
        language: 语言代码，默认'zh'

    Returns:
        识别出的文本
    """
    try:
        res = await async_whisperclient.audio.transcriptions.create(
            model=settings.WHISPER_MODEL,
            file=audio_file,
            language=language
        )
        return res.text
    except Exception as e:
        logger.error(f"[ASYNC_TRANSCRIBE] 语音识别失败: {e}")
        raise


async def async_translate_audio(audio_file: bytes) -> str:
    """
    异步音频翻译（翻译为英文）
    使用AsyncOpenAI客户端，避免阻塞事件循环

    Args:
        audio_file: 音频文件字节数据

    Returns:
        翻译后的英文文本
    """
    try:
        res = await async_whisperclient.audio.translations.create(
            model=settings.WHISPER_MODEL,
            file=audio_file
        )
        return res.text
    except Exception as e:
        logger.error(f"[ASYNC_TRANSLATE_AUDIO] 音频翻译失败: {e}")
        raise


def _normalize_target_language_for_trt(language: str) -> str:
    normalized = (language or "").strip().lower()
    if normalized == "auto":
        raise ValueError("TRT translation no longer supports source/target language 'auto'")
    if not normalized:
        return "en"
    return normalized


async def async_transcribe_trt(audio_file: bytes, language: str = 'zh') -> str:
    """
    使用 WhisperLive-TRT 后端进行语音识别（含自动翻译）。

    TRT 的 language 参数语义是目标语言，不支持 auto。
    """
    target_language = _normalize_target_language_for_trt(language)
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            files = {'file': ('audio.wav', audio_file, 'audio/wav')}
            data = {
                'language': target_language,
                'response_format': 'json',
            }
            response = await client.post(
                f"{WHISPER_TRT_URL}/v1/audio/transcriptions",
                files=files,
                data=data,
            )
            response.raise_for_status()
            result = response.json()
            text = result.get("text", "")
            if not isinstance(text, str):
                logger.warning("[ASYNC_TRANSCRIBE_TRT] Unexpected text payload type: %s", type(text))
                return ""
            return text
    except Exception as e:
        logger.error(f"[ASYNC_TRANSCRIBE_TRT] TRT语音识别失败: {e}")
        raise


async def do_transcribe(audio_file: bytes, language: str = "zh") -> str:
    if settings.WHISPER_BACKEND == "whisper-trt":
        return await async_transcribe_trt(audio_file, language=language)
    return await async_transcribe(audio_file, language=language)


async def do_translate_audio(audio_file: bytes) -> str:
    if settings.WHISPER_BACKEND == "whisper-trt":
        return await async_transcribe_trt(audio_file, language="en")
    return await async_translate_audio(audio_file)


def do_translate(text: str, from_: str, to: str):
    """
    同步翻译函数，多供应商支持故障转移和超时控制
    使用translator库的timeout参数实现超时控制
    """
    # 获取供应商列表
    if not text or not text.strip():
        return ""

    if _is_auto_translation_lang(from_) or _is_auto_translation_lang(to):
        raise ValueError("Translation no longer supports source/target language 'auto'")

    if _is_same_translation_lang(from_, to):
        logger.info(
            "[TRANSLATE] Skip translation for same language pair: source=%s, target=%s",
            from_,
            to,
        )
        return text

    if settings.GEMMA_TRANSLATE_ENABLED:
        if is_gemma_translation_supported(from_, to):
            logger.info(f"[TRANSLATE] Trying TranslateGemma first - source={from_}, target={to}")
            gemma_result = gemma_translate(text, source_lang=from_, target_lang=to)
            if gemma_result is not None:
                logger.info("[TRANSLATE] TranslateGemma succeeded")
                return gemma_result

            logger.warning("[TRANSLATE] TranslateGemma failed")
            if not settings.GEMMA_TRANSLATE_FALLBACK:
                logger.error("[TRANSLATE] Fallback disabled, returning source text")
                return text
        else:
            logger.info(
                "[TRANSLATE] Skip TranslateGemma due to unsupported language pair: source=%s, target=%s",
                from_,
                to,
            )

    services_list = [s.strip() for s in settings.TRANSLATOR_SERVICES_LIST.split(',')]

    translators_module = get_translators()

    # 记录开始翻译
    logger.info(f"[TRANSLATE] 开始翻译 - 原文: '{text[:50]}...', 源语言: {from_}, 目标语言: {to}")
    logger.debug(f"[TRANSLATE] 供应商列表: {services_list}, 超时时间: {settings.TRANSLATION_TIMEOUT}秒")

    # 依次尝试每个供应商
    for i, service in enumerate(services_list):
        try:
            logger.info(f"[TRANSLATE] 尝试供应商 {i+1}/{len(services_list)}: {service}")

            # 处理繁体中文映射
            to_language = transalte_zt.get(service, 'zt') if to == 'zt' else to

            # 执行翻译，使用内置timeout参数
            result = translators_module.translate_text(
                text,
                translator=service,
                from_language=from_,
                to_language=to_language,
                timeout=settings.TRANSLATION_TIMEOUT  # 使用内置超时参数
            )

            result = html.unescape(result)
            logger.info(f"[TRANSLATE] 翻译成功 - 供应商: {service}, 结果: '{result[:50]}...'")
            return result

        except Exception as e:
            logger.warning(f"[TRANSLATE] 供应商 {service} 失败: {type(e).__name__}: {e}")

            # 如果是最后一个供应商，记录错误并返回原文
            if i == len(services_list) - 1:
                logger.error(f"[TRANSLATE] 所有供应商都失败，返回原文 - 已尝试: {services_list}")
                return text

            # 继续尝试下一个供应商
            logger.info(f"[TRANSLATE] 切换到下一个供应商")
            continue

    # 所有供应商都失败，返回原文
    logger.error(f"[TRANSLATE] 翻译失败，所有供应商不可用 - 返回原文")
    return text


def packaged_opus_stream_to_wav_bytes(packaged_opus_data: bytes, sample_rate: int) -> bytes:
    # (此函数逻辑复杂且纯粹，直接从 server.py 复制)
    channels = 1
    frame_duration = 20
    sample_width = 2
    if not packaged_opus_data: return b''
    try:
        decoder = opuslib.Decoder(sample_rate, channels)
    except opuslib.OpusError as e:
        raise RuntimeError(f"创建 Opus 解码器失败: {e}")
    samples_per_packet_frame = int(sample_rate * frame_duration / 1000)
    all_decoded_pcm = bytearray()
    offset = 0
    while offset < len(packaged_opus_data):
        if offset + 4 > len(packaged_opus_data): break
        try:
            packet_len = struct.unpack('>I', packaged_opus_data[offset:offset+4])[0]
        except struct.error: break
        offset += 4
        if offset + packet_len > len(packaged_opus_data): break
        opus_packet = packaged_opus_data[offset:offset+packet_len]
        offset += packet_len
        if not opus_packet: continue
        try:
            decoded_pcm = decoder.decode(opus_packet, samples_per_packet_frame)
            all_decoded_pcm.extend(decoded_pcm)
        except opuslib.OpusError as e:
            logger.warning(f"Opus 解码错误 (跳过包): {e}")
    if not all_decoded_pcm: return b''
    wav_buffer = BytesIO()
    with wave.open(wav_buffer, 'wb') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(sample_rate)
        wf.writeframes(bytes(all_decoded_pcm))
    return wav_buffer.getvalue()
